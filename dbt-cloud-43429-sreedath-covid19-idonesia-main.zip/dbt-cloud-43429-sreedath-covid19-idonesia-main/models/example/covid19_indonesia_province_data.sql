{{ config(materialized='table') }}

select time_zone,Location as Province, TOTAL_RECOVERED,TOTAL_ACTIVE_CASES,"POPULATION",TOTAL_DEATHS,CASE_RECOVERED_RATE,
Current_timestamp() as LOAD_DATE_TIME
from {{source('GOOGLE_SHEETS','COVID_19_INDONESIA_SREEDATH_PS')}}  where Location_level like 'Province'