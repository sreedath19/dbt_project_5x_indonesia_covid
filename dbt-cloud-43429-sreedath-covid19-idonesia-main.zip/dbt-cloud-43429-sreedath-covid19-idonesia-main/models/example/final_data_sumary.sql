with reg_new_rate as (
select Province,
avg(NEW_DEATHS) as death_rate,
avg(NEW_RECOVERED) as recovery_rate,
avg(NEW_CASES) as spreading_rate
from {{ref('region_base_new_rates')}} group by Province),

death_count as (
    select Province,Total_deaths,total_recovered from {{ref('province_aggreagated_death_count')}}
),
pre_final as (
select distinct Province,"POPULATION" from {{ref('covid19_indonesia_province_data')}}
),
final as (
    select a.*,b.Total_deaths,b.total_recovered,c."POPULATION" from reg_new_rate as a join death_count as b on a.Province = b.Province
    join pre_final as c on a.Province = c.Province
)

select *,current_timestamp as LOAD_DATE_TIME from final order by death_rate