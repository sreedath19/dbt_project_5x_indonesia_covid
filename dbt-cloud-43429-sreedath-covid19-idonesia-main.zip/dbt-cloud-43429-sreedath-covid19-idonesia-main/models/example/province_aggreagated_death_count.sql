{{ config(materialized='table') }}
with province_deaths as (
select distinct Location,Total_deaths,TOTAL_RECOVERED,Date,Rank() over (partition by location order by Date desc) as Rank from 
{{source('GOOGLE_SHEETS','COVID_19_INDONESIA_SREEDATH_PS')}} where Location_level not like 'Country')

select distinct Location as province,Total_deaths,total_recovered,current_timestamp() as Load_date_time from  province_deaths where Rank =1