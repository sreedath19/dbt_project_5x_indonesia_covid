with cte as (
select 
avg(NEW_CASES_PER_MILLION) as NEW_CASES_PER_MILLION,avg(NEW_DEATHS_PER_MILLION) as NEW_DEATHS_PER_MILLION,sum(NEW_RECOVERED) as NEW_RECOVERED,
sum(NEW_DEATHS) as NEW_DEATHS,sum(NEW_CASES) as NEW_CASES,"DATE",sum(NEW_ACTIVE_CASES) as NEW_ACTIVE_CASES,LOCATION as Province
from {{source('GOOGLE_SHEETS','COVID_19_INDONESIA_SREEDATH_PS')}} where Location_level like 'Province'
group by Location,"DATE"
)
select *, current_timestamp() as Load_date_time from cte